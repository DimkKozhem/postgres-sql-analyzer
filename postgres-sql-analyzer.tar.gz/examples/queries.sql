-- Примеры SQL запросов для тестирования PostgreSQL SQL Analyzer

-- 1. Простой SELECT
SELECT * FROM users LIMIT 10;

-- 2. SELECT с условием WHERE
SELECT name, email FROM users WHERE active = true;

-- 3. SELECT с JOIN
SELECT u.name, o.order_date, o.total_amount
FROM users u
JOIN orders o ON u.id = o.user_id
WHERE u.active = true AND o.status = 'completed';

-- 4. SELECT с агрегатными функциями
SELECT 
    u.name,
    COUNT(o.id) as order_count,
    SUM(o.total_amount) as total_spent,
    AVG(o.total_amount) as avg_order_value
FROM users u
LEFT JOIN orders o ON u.id = o.user_id
GROUP BY u.id, u.name
HAVING COUNT(o.id) > 0;

-- 5. SELECT с подзапросом
SELECT name, email
FROM users
WHERE id IN (
    SELECT DISTINCT user_id 
    FROM orders 
    WHERE total_amount > 1000
);

-- 6. SELECT с CTE (Common Table Expression)
WITH user_stats AS (
    SELECT 
        user_id,
        COUNT(*) as order_count,
        SUM(total_amount) as total_spent
    FROM orders
    GROUP BY user_id
),
active_users AS (
    SELECT id, name, email
    FROM users
    WHERE active = true
)
SELECT 
    au.name,
    au.email,
    COALESCE(us.order_count, 0) as order_count,
    COALESCE(us.total_spent, 0) as total_spent
FROM active_users au
LEFT JOIN user_stats us ON au.id = us.user_id
ORDER BY us.total_spent DESC NULLS LAST;

-- 7. SELECT с оконными функциями
SELECT 
    name,
    email,
    order_date,
    total_amount,
    ROW_NUMBER() OVER (PARTITION BY u.id ORDER BY o.order_date DESC) as rn,
    LAG(total_amount) OVER (PARTITION BY u.id ORDER BY o.order_date) as prev_amount,
    LEAD(total_amount) OVER (PARTITION BY u.id ORDER BY o.order_date) as next_amount
FROM users u
JOIN orders o ON u.id = o.user_id
WHERE u.active = true;

-- 8. SELECT с UNION
SELECT 'users' as table_name, COUNT(*) as record_count FROM users
UNION ALL
SELECT 'orders' as table_name, COUNT(*) as record_count FROM orders
UNION ALL
SELECT 'products' as table_name, COUNT(*) as record_count FROM products;

-- 9. SELECT с CASE
SELECT 
    name,
    email,
    CASE 
        WHEN active = true THEN 'Активен'
        ELSE 'Неактивен'
    END as status,
    CASE 
        WHEN email LIKE '%@gmail.com' THEN 'Gmail'
        WHEN email LIKE '%@yandex.ru' THEN 'Yandex'
        WHEN email LIKE '%@mail.ru' THEN 'Mail.ru'
        ELSE 'Другое'
    END as email_provider
FROM users;

-- 10. SELECT с EXISTS
SELECT u.name, u.email
FROM users u
WHERE EXISTS (
    SELECT 1 
    FROM orders o 
    WHERE o.user_id = u.id 
    AND o.total_amount > 5000
);

-- 11. SELECT с INNER JOIN нескольких таблиц
SELECT 
    u.name as user_name,
    p.name as product_name,
    oi.quantity,
    oi.unit_price,
    oi.quantity * oi.unit_price as total_price
FROM users u
JOIN orders o ON u.id = o.user_id
JOIN order_items oi ON o.id = oi.order_id
JOIN products p ON oi.product_id = p.id
WHERE o.status = 'completed'
ORDER BY o.order_date DESC;

-- 12. SELECT с LEFT JOIN и фильтрацией
SELECT 
    u.name,
    u.email,
    COUNT(o.id) as order_count,
    COALESCE(SUM(o.total_amount), 0) as total_spent
FROM users u
LEFT JOIN orders o ON u.id = o.user_id AND o.status = 'completed'
GROUP BY u.id, u.name, u.email
HAVING COUNT(o.id) >= 2;

-- 13. SELECT с FULL OUTER JOIN
SELECT 
    COALESCE(u.name, 'Неизвестный пользователь') as user_name,
    COALESCE(p.name, 'Неизвестный продукт') as product_name,
    oi.quantity
FROM users u
FULL OUTER JOIN orders o ON u.id = o.user_id
FULL OUTER JOIN order_items oi ON o.id = oi.order_id
FULL OUTER JOIN products p ON oi.product_id = p.id
WHERE oi.quantity IS NOT NULL;

-- 14. SELECT с CROSS JOIN (осторожно!)
SELECT 
    u.name as user_name,
    p.name as product_name
FROM users u
CROSS JOIN products p
WHERE u.active = true AND p.stock_quantity > 0
LIMIT 100;

-- 15. SELECT с рекурсивным CTE
WITH RECURSIVE user_hierarchy AS (
    -- Базовый случай: пользователи без заказов
    SELECT 
        u.id,
        u.name,
        u.email,
        0 as level
    FROM users u
    WHERE NOT EXISTS (
        SELECT 1 FROM orders o WHERE o.user_id = u.id
    )
    
    UNION ALL
    
    -- Рекурсивный случай: пользователи с заказами
    SELECT 
        u.id,
        u.name,
        u.email,
        uh.level + 1
    FROM users u
    JOIN orders o ON u.id = o.user_id
    JOIN user_hierarchy uh ON o.user_id = uh.id
    WHERE uh.level < 3
)
SELECT * FROM user_hierarchy ORDER BY level, name;

-- 16. SELECT с JSON функциями (PostgreSQL 12+)
SELECT 
    u.name,
    u.email,
    json_build_object(
        'order_count', COUNT(o.id),
        'total_spent', SUM(o.total_amount),
        'last_order', MAX(o.order_date)
    ) as user_stats
FROM users u
LEFT JOIN orders o ON u.id = o.user_id
GROUP BY u.id, u.name, u.email;

-- 17. SELECT с текстовым поиском
SELECT 
    name,
    description,
    price,
    similarity(name, 'ноутбук') as name_similarity,
    similarity(description, 'мощный компьютер') as desc_similarity
FROM products
WHERE 
    name ILIKE '%ноутбук%' OR 
    description ILIKE '%мощный%' OR
    similarity(name, 'ноутбук') > 0.3
ORDER BY name_similarity DESC, desc_similarity DESC;

-- 18. SELECT с временными функциями
SELECT 
    u.name,
    u.email,
    u.created_at,
    o.order_date,
    EXTRACT(DAY FROM (o.order_date - u.created_at)) as days_to_first_order,
    EXTRACT(MONTH FROM u.created_at) as birth_month
FROM users u
LEFT JOIN (
    SELECT 
        user_id,
        MIN(order_date) as order_date
    FROM orders
    GROUP BY user_id
) o ON u.id = o.user_id
WHERE u.created_at >= '2023-01-01';

-- 19. SELECT с условной агрегацией
SELECT 
    u.name,
    COUNT(CASE WHEN o.status = 'completed' THEN 1 END) as completed_orders,
    COUNT(CASE WHEN o.status = 'pending' THEN 1 END) as pending_orders,
    COUNT(CASE WHEN o.status = 'cancelled' THEN 1 END) as cancelled_orders,
    SUM(CASE WHEN o.status = 'completed' THEN o.total_amount ELSE 0 END) as completed_amount
FROM users u
LEFT JOIN orders o ON u.id = o.user_id
GROUP BY u.id, u.name;

-- 20. SELECT с оконными функциями и ранжированием
SELECT 
    name,
    email,
    order_count,
    total_spent,
    RANK() OVER (ORDER BY total_spent DESC) as spending_rank,
    DENSE_RANK() OVER (ORDER BY order_count DESC) as order_rank,
    NTILE(4) OVER (ORDER BY total_spent DESC) as spending_quartile
FROM (
    SELECT 
        u.name,
        u.email,
        COUNT(o.id) as order_count,
        COALESCE(SUM(o.total_amount), 0) as total_spent
    FROM users u
    LEFT JOIN orders o ON u.id = o.user_id
    GROUP BY u.id, u.name, u.email
) user_summary
WHERE order_count > 0;
