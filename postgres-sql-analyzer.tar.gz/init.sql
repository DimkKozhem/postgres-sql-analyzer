-- Инициализация тестовой базы данных для PostgreSQL SQL Analyzer

-- Создаем расширение pg_stat_statements
CREATE EXTENSION IF NOT EXISTS pg_stat_statements;

-- Создаем тестовые таблицы
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS orders (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(50) DEFAULT 'pending',
    total_amount DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS products (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    category VARCHAR(100),
    stock_quantity INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS order_items (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES orders(id),
    product_id INTEGER REFERENCES products(id),
    quantity INTEGER NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Создаем индексы для оптимизации
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_active ON users(active);
CREATE INDEX IF NOT EXISTS idx_orders_user_id ON orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_date ON orders(order_date);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);
CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON order_items(order_id);

-- Вставляем тестовые данные
INSERT INTO users (name, email, active) VALUES
    ('Иван Иванов', 'ivan@example.com', true),
    ('Петр Петров', 'petr@example.com', true),
    ('Анна Сидорова', 'anna@example.com', false),
    ('Мария Козлова', 'maria@example.com', true),
    ('Сергей Волков', 'sergey@example.com', true)
ON CONFLICT (email) DO NOTHING;

INSERT INTO products (name, description, price, category, stock_quantity) VALUES
    ('Ноутбук Dell XPS 13', 'Мощный ноутбук для работы и учебы', 89999.99, 'Электроника', 10),
    ('iPhone 15 Pro', 'Смартфон премиум класса', 129999.99, 'Электроника', 25),
    ('Книга "Искусство программирования"', 'Классический учебник по алгоритмам', 2999.99, 'Книги', 100),
    ('Наушники Sony WH-1000XM4', 'Беспроводные наушники с шумоподавлением', 29999.99, 'Электроника', 15),
    ('Кофемашина DeLonghi', 'Автоматическая кофемашина', 45999.99, 'Бытовая техника', 5)
ON CONFLICT DO NOTHING;

-- Вставляем заказы
INSERT INTO orders (user_id, status, total_amount) VALUES
    (1, 'completed', 92999.98),
    (2, 'pending', 29999.99),
    (1, 'completed', 2999.99),
    (4, 'shipped', 129999.99),
    (5, 'completed', 45999.99)
ON CONFLICT DO NOTHING;

-- Вставляем элементы заказов
INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES
    (1, 1, 1, 89999.99),
    (1, 3, 1, 2999.99),
    (2, 4, 1, 29999.99),
    (3, 3, 1, 2999.99),
    (4, 2, 1, 129999.99),
    (5, 5, 1, 45999.99)
ON CONFLICT DO NOTHING;

-- Обновляем статистику
ANALYZE users;
ANALYZE orders;
ANALYZE products;
ANALYZE order_items;

-- Создаем пользователя только для чтения (если нужно)
-- CREATE USER readonly WITH PASSWORD 'readonly123';
-- GRANT CONNECT ON DATABASE testdb TO readonly;
-- GRANT USAGE ON SCHEMA public TO readonly;
-- GRANT SELECT ON ALL TABLES IN SCHEMA public TO readonly;
-- GRANT SELECT ON ALL SEQUENCES IN SCHEMA public TO readonly;
-- ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON TABLES TO readonly;
