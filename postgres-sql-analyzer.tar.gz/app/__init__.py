# PostgreSQL SQL Analyzer
__version__ = "0.1.0"
